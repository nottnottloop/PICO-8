function _init()
	logo_scale_size=0.45
	
	logo_width=16*8*logo_scale_size
	logo_height=7*8*logo_scale_size
	x=flr(rnd(128-logo_width))
	y=flr(rnd(128-logo_height))

	speed=0.15
	speed_increment=0.07
	x_vel=speed * (rnd(1) < 0.5 and -1 or 1)
	y_vel=speed * (rnd(1) < 0.5 and -1 or 1)

	current_color=7
	new_color=current_color
	message_color=10
	message_x_offset=0
	message_y_offset=0

	sound=false
	music_playing=false
end

function _update60()
	-- basic logic
	x-=x_vel
	y-=y_vel
	if y<0 or y+logo_height>128 then
		y_vel*=-1
		collide()
	end
	if x<0 or x+logo_width>128 then
		x_vel*=-1
		collide()
	end

	-- easter eggs
	if speed > 2 then
		if btn(⬅️) or btn(⬇️) then
				change_speed(-speed_increment)
		end
		if btn(➡️) or btn(⬆️) then
			change_speed(speed_increment)
		end	
	else
		if btnp(⬅️) or btnp(⬇️) then
			change_speed(-speed_increment)
		end
		if btnp(➡️) or btnp(⬆️) then
			change_speed(speed_increment)
		end	
	end

	if btnp(🅾️) then
		if not sound then
			sfx(1)
		end
		sound=not sound
	end
end

function _draw()
	cls()
	pal(7,current_color,1)
	sspr(0,0,16*8,7*8,x,y,logo_width,logo_height)
	if speed > 25 then
		print(x_vel.."\n"..y_vel,0,0,8)
	end
	if speed > 35 then
		message="holy fuck stop"
		print(message,64-#message*2+message_x_offset,63+message_y_offset,message_color)
	end
	if speed > 50 then
		message_color=rnd(16)
	else
		message_color=10
	end
	if speed > 60 then
		if not music_playing then
			music(0)
			music_playing=true
		end
	else
		music(-1)
		music_playing=false
	end
	if speed > 75 then
		message_y_offset=(speed-75)*3*cos(t()/0.5)
	else
		message_y_offset=0
	end
	if speed > 85 then
		message_x_offset=(speed-85)*4*sin(t()/0.5)
	else
		message_x_offset=0
	end
	if speed > 100 then
		sfx(3)
		_init()
	end
end

function collide()
	while new_color == current_color do
		new_color = flr(rnd(15)) + 1
	end
	current_color=new_color
	if sound then
		sfx(0)
	end
end

function change_speed(change)
	if speed+change > 0.05 then
		speed+=change
	end
	x_vel=speed * (x_vel < 0 and -1 or 1)
	y_vel=speed * (y_vel < 0 and -1 or 1)
end