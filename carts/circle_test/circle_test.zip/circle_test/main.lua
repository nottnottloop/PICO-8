
function _init()
	circle_radius = 24

	x=63
	y=63
	move_x=63
	move_y=63
end

function _update60()
	-- movement
	if btn(⬅️) then
		move_x -= 2
	end
	if btn(➡️) then
		move_x += 2
	end
	if btn(⬆️) then
		move_y -= 2
	end
	if btn(⬇️) then
		move_y += 2
	end
	if btn(🅾️) then
		music(0)
	end

	-- bounds
	if move_x < 0 + circle_radius then
		move_x = 128 - circle_radius
		collide()
	end
	if move_x + circle_radius > 128 then
		move_x = 0 + circle_radius
		collide()
	end
	if move_y < 0 + circle_radius then
		move_y = 128 - circle_radius
		collide()
	end
	if move_y + circle_radius > 128 then
		move_y = 0 + circle_radius
		collide()
	end
end

function collide()
	sfx(2)
end

function _draw()
	cls(7)
	print("wait this isn't japan")
	circfill(move_x,move_y,circle_radius,8)
end